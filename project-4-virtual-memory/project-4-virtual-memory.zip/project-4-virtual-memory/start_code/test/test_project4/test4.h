#ifndef INCLUDE_TASK4_H_
#define INCLUDE_TASK4_H_

#include "type.h"

//test drawing
void drawing_task1(void);

//test memory
void rw_task1(void);
void rw_task2(void);
void rw_task3(void);

#endif
