#ifndef INCLUDE_TEST_H
#define INCLUDE_TEST_H

#include "test4.h"
#include "sched.h"
#include "type.h"

void test_shell();
extern struct task_info *test_tasks[4];

#endif
